from flask import Blueprint, render_template, request, url_for, redirect, flash, session, g
from config import get_api_key
from flask_wtf import FlaskForm
from wtforms import StringField, widgets, SelectField, IntegerField, SelectMultipleField
from wtforms.validators import DataRequired


from pybo.models import LocalCenter, LocalProperty

from pybo import db  # mysql db 연결 객체를 가져옵니다.

bp = Blueprint('main', __name__, url_prefix='/')


class MultiCheckboxField(SelectMultipleField):
    widget = widgets.ListWidget(prefix_label=True)
    option_widget = widgets.CheckboxInput()


class AddMarkerForm1(FlaskForm):
    string_of_targets = ['영유아\r\n초등학생\r\n중학생\r\n고등학생\r\n']
    list_of_targets = string_of_targets[0].split()
    targets = [(x, x) for x in list_of_targets]

    string_of_subjects = [
        '국어\r\n영어\r\n수학\r\n사회\r\n과학\r\n제2외국어\r\n논술\r\n예체능\r\n코딩\r\n교구학습\r\n창의력\r\n']
    list_of_subjects = string_of_subjects[0].split()
    subjects = [(x, x) for x in list_of_subjects]

    centerNm = StringField('centerNm',  validators=[DataRequired()])
    centerDesc = StringField('centerDesc', validators=[DataRequired()])
    brandNm = SelectField('brandNm', choices=[('미래탐구', '미래탐구'), ('소마', '소마'), (
        '뉴스터디', '뉴스터디'), ('하이스트', '하이스트'), ('플레이팩토', '플레이팩토'), ('르네상스', '르네상스'), ('ELC', 'ELC')])
    branchNm = SelectField('branchNm', choices=[(
        '대치지점', '대치지점'), ('성북지점', '성북지점'), ('동대문지점', '동대문지점'), ('광화문지점', '광화문지점'), ('목동지점', '목동지점')])
    address = StringField('address', validators=[DataRequired()])
    detailAddress = StringField('detailAddress')
    target = MultiCheckboxField('target', choices=targets)
    subject = MultiCheckboxField('subject', choices=subjects)


class AddMarkerForm2():
    property_nm = StringField('propertyNm',  validators=[DataRequired()])
    property_desc = StringField('propertyDesc', validators=[DataRequired()])
    address = StringField('address', validators=[DataRequired()])


@ bp.route('/', methods=['GET', 'POST'])
def main_page():
    context = {'api_key': get_api_key()}
    form = AddMarkerForm1()

    return render_template('map/index.html', context=context, form=form)


@ bp.route('/center/create', methods=['POST'])
def create():
    center_nm = request.form['centerNm']
    center_desc = request.form['centerDesc']
    brand_nm = request.form['brandNm']
    branch_nm = request.form['branchNm']

    target = request.form.getlist('target')
    target = ','.join(target)

    subject = request.form.getlist('subject')
    subject = ','.join(subject)

    address = request.form['address']

    if request.form['detailAddress']:
        detail_address = request.form['detailAddress']
    else:
        detail_address = ''

    if request.form['option1Nm']:
        option1_nm = request.form['option1Nm']
    else:
        option1_nm = ''

    if request.form['option1Desc']:
        option1_desc = request.form['option1Desc']
    else:
        option1_desc = ''

    # if request.form['option2Nm']:
    #     option2_nm = request.form['option2Nm']
    # else:
    #     option2_nm = ''

    # if request.form['option2Desc']:
    #     option2_desc = request.form['option2Desc']

    # if request.form['option3Nm']:
    #     option3_nm = request.form['option3Nm']

    # if request.form['option3Desc']:
    #     option3_desc = request.form['option3Desc']

    # if request.form['option4Nm']:
    #     option4_nm = request.form['option4Nm']

    # if request.form['option4Desc']:
    #     option4_desc = request.form['option4Desc']

    # if request.form['option5Nm']:
    #     option5_nm = request.form['option5Nm']

    # if request.form['option5Desc']:
    #     option5_desc = request.form['option5Desc']

    # if request.form['option6Nm']:
    #     option6_nm = request.form['option6Nm']

    # if request.form['option6Desc']:
    #     option6_desc = request.form['option6Desc']

    # if request.form['option7Nm']:
    #     option7_nm = request.form['option7Nm']

    # if request.form['option7Desc']:
    #     option7_desc = request.form['option7Desc']

    # if request.form['option8Nm']:
    #     option8_nm = request.form['option8Nm']

    # if request.form['option8Desc']:
    #     option8_desc = request.form['option8Desc']

    # if request.form['option9Nm']:
    #     option9_nm = request.form['option9Nm']

    # if request.form['option9Desc']:
    #     option9_desc = request.form['option9Desc']

    # if request.form['option10Nm']:
    #     option10_nm = request.form['option10Nm']

    # if request.form['option10Desc']:
    #     option10_desc = request.form['option10Desc']

    # if request.form['option11Nm']:
    #     option11_nm = request.form['option11Nm']

    # if request.form['option11Desc']:
    #     option11_desc = request.form['option11Desc']

    # if request.form['option12Nm']:
    #     option12_nm = request.form['option12Nm']

    # if request.form['option12Desc']:
    #     option12_desc = request.form['option12Desc']

    # if request.form['option13Nm']:
    #     option13_nm = request.form['option13Nm']

    # if request.form['option13Desc']:
    #     option13_desc = request.form['option13Desc']

    # if request.form['option14Nm']:
    #     option14_nm = request.form['option14Nm']

    # if request.form['option14Desc']:
    #     option14_desc = request.form['option14Desc']

    # if request.form['option15Nm']:
    #     option15_nm = request.form['option15Nm']

    # if request.form['option15Desc']:
    #     option15_desc = request.form['option15Desc']

    center = LocalCenter(center_nm=center_nm, center_desc=center_desc, brand_nm=brand_nm, branch_nm=branch_nm, target=target,
                         subject=subject, address=address, detail_address=detail_address, )

    db.session.add(center)
    db.session.commit()
    return redirect(url_for('main.mylist'))


@ bp.route('/mylist')
def mylist():
    center_list = LocalCenter.query.order_by(LocalCenter.create_dttm.desc())
    center_cnt = center_list.count()
    property_list = LocalProperty.query.order_by(
        LocalProperty.create_dttm.desc())
    property_cnt = property_list.count()
    price_list = []
    for i in property_list:  # 가격을 한글단위로 변환
        price_list.append(convert_number_to_krw(i.price))

    return render_template('map/mylist.html', center_list=center_list, center_cnt=center_cnt, property_list=property_list, property_cnt=property_cnt, price_list=price_list)


def convert_number_to_krw(num_amount, ndigits_round=0, str_suffix='원'):
    """숫자를 자릿수 한글단위와 함께 리턴한다 """
    assert isinstance(num_amount, int) and isinstance(ndigits_round, int)
    assert num_amount >= 1, '최소 1원 이상 입력되어야 합니다'
    # 일, 십, 백, 천, 만, 십, 백, 천, 억, ... 단위 리스트를 만든다.
    maj_units = ['만', '억', '조', '경', '해', '자',
                 '양', '구', '간', '정', '재', '극']  # 10000 단위
    units = [' ']  # 시작은 일의자리로 공백으로하고 이후 십, 백, 천, 만...
    for mm in maj_units:
        units.extend(['십', '백', '천'])  # 중간 십,백,천 단위
        units.append(mm)

    list_amount = list(str(round(num_amount, ndigits_round))
                       )  # 라운딩한 숫자를 리스트로 바꾼다
    list_amount.reverse()  # 일, 십 순서로 읽기 위해 순서를 뒤집는다

    str_result = ''  # 결과
    num_len_list_amount = len(list_amount)

    for i in range(num_len_list_amount):
        str_num = list_amount[i]
        # 만, 억, 조 단위에 천, 백, 십, 일이 모두 0000 일때는 생략
        if num_len_list_amount >= 9 and i >= 4 and i % 4 == 0 and ''.join(list_amount[i: i+4]) == '0000':
            continue
        if str_num == '0':  # 0일 때
            if i % 4 == 0:  # 4번째자리일 때(만, 억, 조...)
                str_result = units[i] + str_result  # 단위만 붙인다
        elif str_num == '1':  # 1일 때
            if i % 4 == 0:  # 4번째자리일 때(만, 억, 조...)
                str_result = str_num + units[i] + str_result  # 숫자와 단위를 붙인다
            else:  # 나머지자리일 때
                str_result = units[i] + str_result  # 단위만 붙인다
        else:  # 2~9일 때
            str_result = str_num + units[i] + str_result  # 숫자와 단위를 붙인다
    str_result = str_result.strip()  # 문자열 앞뒤 공백을 제거한다
    if len(str_result) == 0:
        return None
    if not str_result[0].isnumeric():  # 앞이 숫자가 아닌 문자인 경우
        str_result = '1' + str_result  # 1을 붙인다
    return str_result + str_suffix  # 접미사를 붙인다
