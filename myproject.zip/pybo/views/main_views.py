import pandas as pd
from pprint import pprint
import requests

from flask import Flask, Blueprint, render_template, request, json, Response, url_for, redirect, flash, session, g
from config import get_api_key

from pybo.models import LocalCenter as Center, LocalProperty as Property, CenterListSchema as CenterListSchema, CenterDetailSchema as CenterDetailSchema

import pybo.data as data

from pybo.forms import AddMarkerForm1, AddMarkerForm2
from pybo import db  # mysql db 연결 객체를 가져옵니다.

from pybo.utils import convert_number_to_krw, is_json_key_present

centers_schema = CenterListSchema()
center_detail_schema = CenterDetailSchema()

bp = Blueprint('main', __name__, url_prefix='/')

# 메인 페이지


@bp.route('/', methods=['GET', 'POST'])
def main_page():
    context = {'api_key': get_api_key()}
    form = AddMarkerForm1()
    form2 = AddMarkerForm2()
    return render_template('map/index.html', context=context, form=form, form2=form2)

# 마이맵 리스트 데이터 로드


@bp.route('/loaddata', methods=['GET', 'POST'])
def loaddata():
    rdata = request
    # pprint(rdata)

    centers = Center.query.order_by(Center.center_seq.desc()).all()
    centers_data = centers_schema.dump(centers, many=True)
    # pprint(centers_data)
    # property = Property.query.order_by(Property.property_seq.desc()).all()

    # price_list = []
    # for i in property:  # 가격을 한글단위로 변환
    #     price_list.append(convert_number_to_krw(i.price))

    # print(property)
    # print(price_list)

    rdata = {"center": centers_data}

    # pprint(rdata)

    return custom_response(rdata, 200)

# 교육기관 상세 페이지


@ bp.route('/detailpage/<int:center_seq>', methods=['GET', 'POST'])
def getCenterDetailpage(center_seq):
    print("센터 상세 페이지 요청")
    rdata = request
    center_detail = Center.query.get(center_seq)
    center_detail = center_detail_schema.dump(center_detail, many=False)
    pprint(center_detail)
    rdata = {"center": center_detail}
    pprint(rdata)
    return custom_response(rdata, 200)


@bp.route('/test')
def test():
    context = {'api_key': get_api_key()}
    return render_template('add2coord.html', context=context)

# 가장 최근에 등록된 교육기관 정보 로드


@bp.route('/center/latest', methods=['GET'])
def getLatestCenter():
    print(" ------------ 최신 데이터 로드 ------------ ")
    center = Center.query.order_by(Center.center_seq.desc()).first()
    center = center_detail_schema.dump(center, many=False)
    pprint(center)
    rdata = {"center": center}
    
    pprint(rdata)
    return custom_response(rdata, 200)

# kakao map api 주소 좌표 변환


@bp.route('/coord', methods=['GET'])
def getCoord(addr='서울 송파구 오금로32길 31'):
    url = "https://dapi.kakao.com/v2/local/search/address.json"

    queryString = {'query': addr}
    header = {'Authorization': 'KakaoAK 61b0e22977c8f913e6847d3c12019ca2'}

    response = requests.get(url, headers=header, params=queryString)
    tokens = response.json()
    lat = tokens['documents'][0]['y']
    lan = tokens['documents'][0]['x']
    rdata = {"lat": lat, "lan": lan}
    pprint(rdata)
    return custom_response(rdata, 200)


# 교육기관 등록
@bp.route('/center/create', methods=['POST'])
def create1():
    print("센터 등록 요청")

    center_json = request.get_json()
    pprint(center_json)

    center_nm = center_json['centerNm']
    center_desc = center_json['centerDesc']
    brand_nm = center_json['brandNm']
    branch_nm = center_json['branchNm']

    target = center_json['target']
    if type(target) is list:
        target = ",".join(target)
        print(target)

    subject = center_json['subject']
    if type(subject) is list:
        subject = ",".join(subject)
        pprint(subject)

    address = center_json['address']
    
    if center_json['detailAddress'] == None:
        detail_address = ""
    else:
        detail_address = center_json['detailAddress']

    lat = center_json['lat']
    lng = center_json['lng']
    
    if is_json_key_present(center_json, 'option1Nm'):
        option1_nm = center_json['option1Nm']
    else:
        option1_nm = ""

    if is_json_key_present(center_json, 'option1Desc'):
        option1_desc = center_json['option1Desc']
    else:
        option1_desc = ""

    if is_json_key_present(center_json, 'option2Nm'):
        option2_nm = center_json['option2Nm']
    else:
        option2_nm = ""

    if is_json_key_present(center_json, 'option2Desc'):
        option2_desc = center_json['option2Desc']
    else:
        option2_desc = ""

    if is_json_key_present(center_json, 'option3Nm'):
        option3_nm = center_json['option3Nm']
    else:
        option3_nm = ""

    if is_json_key_present(center_json, 'option3Desc'):
        option3_desc = center_json['option3Desc']
    else:
        option3_desc = ""

    if is_json_key_present(center_json, 'option4Nm'):
        option4_nm = center_json['option4Nm']
    else:
        option4_nm = ""

    if is_json_key_present(center_json, 'option4Desc'):
        option4_desc = center_json['option4Desc']
    else:
        option4_desc = ""

    if is_json_key_present(center_json, 'option5Nm'):
        option5_nm = center_json['option5Nm']
    else:
        option5_nm = ""

    if is_json_key_present(center_json, 'option5Desc'):
        option5_desc = center_json['option5Desc']
    else:
        option5_desc = ""

    if is_json_key_present(center_json, 'option6Nm'):
        option6_nm = center_json['option6Nm']
    else:
        option6_nm = ""

    if is_json_key_present(center_json, 'option6Desc'):
        option6_desc = center_json['option6Desc']
    else:
        option6_desc = ""

    if is_json_key_present(center_json, 'option7Nm'):
        option7_nm = center_json['option7Nm']
    else:
        option7_nm = ""

    if is_json_key_present(center_json, 'option7Desc'):
        option7_desc = center_json['option7Desc']
    else:
        option7_desc = ""

    if is_json_key_present(center_json, 'option8Nm'):
        option8_nm = center_json['option8Nm']
    else:
        option8_nm = ""

    if is_json_key_present(center_json, 'option8Desc'):
        option8_desc = center_json['option8Desc']
    else:
        option8_desc = ""

    if is_json_key_present(center_json, 'option9Nm'):
        option9_nm = center_json['option9Nm']
    else:
        option9_nm = ""

    if is_json_key_present(center_json, 'option9Desc'):
        option9_desc = center_json['option9Desc']
    else:
        option9_desc = ""

    if is_json_key_present(center_json, 'option10Nm'):
        option10_nm = center_json['option10Nm']
    else:
        option10_nm = ""

    if is_json_key_present(center_json, 'option10Desc'):
        option10_desc = center_json['option10Desc']
    else:
        option10_desc = ""

    if is_json_key_present(center_json, 'option11Nm'):
        option11_nm = center_json['option11Nm']
    else:
        option11_nm = ""

    if is_json_key_present(center_json, 'option11Desc'):
        option11_desc = center_json['option11Desc']
    else:
        option11_desc = ""

    if is_json_key_present(center_json, 'option12Nm'):
        option12_nm = center_json['option12Nm']
    else:
        option12_nm = ""

    if is_json_key_present(center_json, 'option12Desc'):
        option12_desc = center_json['option12Desc']
    else:
        option12_desc = ""

    if is_json_key_present(center_json, 'option13Nm'):
        option13_nm = center_json['option13Nm']
    else:
        option13_nm = ""

    if is_json_key_present(center_json, 'option13Desc'):
        option13_desc = center_json['option13Desc']
    else:
        option13_desc = ""

    if is_json_key_present(center_json, 'option14Nm'):
        option14_nm = center_json['option14Nm']
    else:
        option14_nm = ""

    if is_json_key_present(center_json, 'option14Desc'):
        option14_desc = center_json['option14Desc']
    else:
        option14_desc = ""

    if is_json_key_present(center_json, 'option15Nm'):
        option15_nm = center_json['option15Nm']
    else:
        option15_nm = ""

    if is_json_key_present(center_json, 'option15Desc'):
        option15_desc = center_json['option15Desc']
    else:
        option15_desc = ""

    # center 정보를 저장합니다.
    try:
        center = Center(center_nm=center_nm, center_desc=center_desc, brand_nm=brand_nm, branch_nm=branch_nm, target=target,
                        subject=subject, address=address, detail_address=detail_address, lat = lat, lng = lng, option1_nm=option1_nm, option1_desc=option1_desc, option2_nm=option2_nm, option2_desc=option2_desc, option3_nm=option3_nm, option3_desc=option3_desc, option4_nm=option4_nm, option4_desc=option4_desc, option5_nm=option5_nm, option5_desc=option5_desc, option6_nm=option6_nm, option6_desc=option6_desc, option7_nm=option7_nm, option7_desc=option7_desc, option8_nm=option8_nm, option8_desc=option8_desc, option9_nm=option9_nm, option9_desc=option9_desc, option10_nm=option10_nm, option10_desc=option10_desc, option11_nm=option11_nm, option11_desc=option11_desc, option12_nm=option12_nm, option12_desc=option12_desc, option13_nm=option13_nm, option13_desc=option13_desc, option14_nm=option14_nm, option14_desc=option14_desc, option15_nm=option15_nm, option15_desc=option15_desc)
        db.session.add(center)
        db.session.commit()
        pprint(center)
        print("center 추가 성공")
        return "1"
    except Exception as e:
        print("center 추가 실패")
        print(e)
        return "0"


def custom_response(res, status_code):
    return Response(mimetype="application/json", response=json.dumps(res), status=status_code)
