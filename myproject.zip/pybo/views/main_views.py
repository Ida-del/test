from flask import Blueprint, render_template, request, url_for, redirect, flash, session, g
from config import get_api_key

from pybo.models import LocalCenter, LocalProperty
from pybo import db  # mysql db 연결 객체를 가져옵니다.
from pybo.forms import AddMarkerForm1

import pybo.data as data


bp = Blueprint('main', __name__, url_prefix='/')


@ bp.route('/', methods=['GET', 'POST'])
def main_page():
    context = {'api_key': get_api_key()} # api_key를 context에 담아서 전달합니다.
    form = AddMarkerForm1() # 폼 객체를 생성합니다.
    
    
    center_list = LocalCenter.query.order_by(LocalCenter.create_dttm.desc())  # 최신순으로 정렬
    center_cnt = center_list.count()  # 총 개수를 구합니다.
    property_list = LocalProperty.query.order_by(
        LocalProperty.create_dttm.desc())  # 최신순으로 정렬
    property_cnt = property_list.count()   # 총 개수를 구합니다.
    price_list = []  # 가격을 한글단위로 변환한 리스트를 담을 변수
    for i in property_list:  # 가격을 한글단위로 변환
        price_list.append(convert_number_to_krw(i.price))
        
    return render_template('map/index.html', context=context, form=form, center_list=center_list, center_cnt=center_cnt, property_list=property_list, property_cnt=property_cnt, price_list=price_list)




@ bp.route('/center/<int:center_seq>')
def center(center_seq):
    center = data.get_center(center_seq)
    return render_template('console/mymap-detail.html', center_detail=center)


def convert_number_to_krw(num_amount, ndigits_round=0, str_suffix='원'):
    """숫자를 자릿수 한글단위와 함께 리턴한다 """
    assert isinstance(num_amount, int) and isinstance(ndigits_round, int)
    assert num_amount >= 1, '최소 1원 이상 입력되어야 합니다'
    # 일, 십, 백, 천, 만, 십, 백, 천, 억, ... 단위 리스트를 만든다.
    maj_units = ['만', '억', '조', '경', '해', '자',
                 '양', '구', '간', '정', '재', '극']  # 10000 단위
    units = [' ']  # 시작은 일의자리로 공백으로하고 이후 십, 백, 천, 만...
    for mm in maj_units:
        units.extend(['십', '백', '천'])  # 중간 십,백,천 단위
        units.append(mm)

    list_amount = list(str(round(num_amount, ndigits_round))
                       )  # 라운딩한 숫자를 리스트로 바꾼다
    list_amount.reverse()  # 일, 십 순서로 읽기 위해 순서를 뒤집는다

    str_result = ''  # 결과
    num_len_list_amount = len(list_amount)

    for i in range(num_len_list_amount):
        str_num = list_amount[i]
        # 만, 억, 조 단위에 천, 백, 십, 일이 모두 0000 일때는 생략
        if num_len_list_amount >= 9 and i >= 4 and i % 4 == 0 and ''.join(list_amount[i: i+4]) == '0000':
            continue
        if str_num == '0':  # 0일 때
            if i % 4 == 0:  # 4번째자리일 때(만, 억, 조...)
                str_result = units[i] + str_result  # 단위만 붙인다
        elif str_num == '1':  # 1일 때
            if i % 4 == 0:  # 4번째자리일 때(만, 억, 조...)
                str_result = str_num + units[i] + str_result  # 숫자와 단위를 붙인다
            else:  # 나머지자리일 때
                str_result = units[i] + str_result  # 단위만 붙인다
        else:  # 2~9일 때
            str_result = str_num + units[i] + str_result  # 숫자와 단위를 붙인다
    str_result = str_result.strip()  # 문자열 앞뒤 공백을 제거한다
    if len(str_result) == 0:
        return None
    if not str_result[0].isnumeric():  # 앞이 숫자가 아닌 문자인 경우
        str_result = '1' + str_result  # 1을 붙인다
    return str_result + str_suffix  # 접미사를 붙인다
