
/* 선택 항목 추가 */
function addOptsBtn() {
    alert(" 추가 버튼 클릭");
    let i = $('.subitem-box').length;

    if (i < 15) {
        alert("선택항목을 추가합니다.");
        var add_item = '<div class="subitem-box multi-box">' +
            '<div class="box short">' +
            '<input class="form-control" name="option' + (i + 1) + 'Nm" id="option' + (i + 1) + 'Nm" maxlength="100" placeholder="제목" type="text" value="" />' +
            '</div>' +
            '<div class="box long">' +
            '<input class="form-control"  name="option' + (i + 1) + 'Desc" id="option' + (i + 1) + 'Desc" maxlength="100" placeholder="선택항목을 입력하세요." type="text" value="" />' +
            '</div>' +
            '<button type="button" class="btn btn-light" onclick="removeOptsBtn(this)">삭제</button>' +
            '</div>';
        // var add_item = '<div class="subitem-box multi-box">' +
        //     '<label for="option' + (i + 1) + '">선택항목' + (i + 1) + '</label><input name="option' + (i + 1) + '" / >' +
        //     '<button type="button" class="btn btn-light" onclick="removeOptsBtn(this)">삭제</button>' +
        //     '</div>';
        $("#optsWrap").append(add_item);
    } else {
        alert("선택항목은 최대 15개까지 추가할 수 있습니다.");
        return false;
    }
};

/* 선택 항목 삭제 */
function removeOptsBtn(self) {
    console.log("삭제 버튼 클릭");
    console.log($(self));
    $(self).parent().remove();

    changeOptsName();
};

/* 선택 항목 속성 (name, id) 이름 넘버링 */
function changeOptsName() {
    console.log("선택항목 이름 변경");
    let i = $('.subitem-box').length;
    console.log("선택항목 개체 수 : " + i);
    for (let j = 0; j < i; j++) {
        console.log("선택항목 개체 수 : " + j);
        $('.subitem-box').eq(j).find('input').eq(0).attr('name', 'option' + (j + 1) + 'Nm');
        $('.subitem-box').eq(j).find('input').eq(0).attr('id', 'option' + (j + 1) + 'Nm');
        $('.subitem-box').eq(j).find('input').eq(1).attr('name', 'option' + (j + 1) + 'Desc');
        $('.subitem-box').eq(j).find('input').eq(1).attr('id', 'option' + (j + 1) + 'Desc');
    }
};

/* 마이맵 리스트 div 요소 생성  */
function createDivCardArea() {
    let tagArea = document.getElementById('mymapList');
    let divCardHeader = document.createElement('div');
    divCardHeader.setAttribute('class', 'card-header');

    let cardHeaderInner = " 마이맵 리스트 ";
    cardHeaderInner += `    <button type="button" onclick="openMymapList('0')" class="btn btn-light">닫기</button>`;
    divCardHeader.innerHTML = cardHeaderInner;

    tagArea.appendChild(divCardHeader);

    let divCardBody = document.createElement('div');
    divCardBody.setAttribute('class', 'card-body');
    divCardBody.setAttribute('id', 'load-data');
    tagArea.appendChild(divCardBody);
}
/* 마이맵 리스트 데이터 로드 | 교육기관+부동산  */
function loaddata() {
    $("#mymapList").html('');
    createDivCardArea();

    $.ajax({
        url: "/loaddata",
        type: "get",
        success: function (rdata) {
            console.log(rdata);
            let contents = "";
            if (rdata == null || rdata == undefined || rdata == "") {
                contents += "<div class='no-data'>등록된 데이터가 없습니다.</div>";
            } else {
                contents += "<div class='has-data'><h2> 교육기관 : " + rdata.center.length + "건</h2></div>";
                $.each(rdata.center, function (key, value) {

                    contents += "<div> ";
                    contents += "   <div class='multi-box'> ";
                    contents += `       <h3><a href="javascript:moveDetailPage('center',` + `'` + value.center_seq + `')">` + value.center_nm + ` </a></h3>`;
                    contents += "       <div align='right'>";
                    contents += "           <button class='btn btn-primary'>수정</button>"
                    contents += "           <button class='btn btn-primary'>삭제</button>"
                    contents += "       </div>";
                    contents += "   </div>";

                    contents += "   <p>" + value.address + " " + value.detail_address + "</p>";
                    contents += "   <p>대상: " + value.target + " | 과목: " + value.subject + "</p>";
                    contents += "</div>";

                    // contents += "<div class='has-data'> 부동산 : " + rdata.property.length + "개</div>";
                });
                $("#load-data").append(contents);
            }
        }, error: function (result) {
            console.log(result);
        }
    });
}

/* 마이맵 리스트 OPEN/CLOSE */
function openMymapList(flag) {
    if (flag == "1") {
        console.log("마이맵 리스트 오픈");
        $("#mymapList").show();
        loaddata(); // 마이맵 리스트 데이터 로드
    } else if (flag == "0") {
        console.log("마이맵 리스트 close");
        $("#mymapList").hide();
    }
}
/* 마이맵 리스트 상세페이지 이동 */
function moveDetailPage(type, seq) {
    $("#mymapList").html('');
    if (type == "center") {
        console.log("마이맵 리스트 상세페이지 이동");
        $.ajax({
            url: "/detailpage/" + seq,
            type: "get",
            success: function (rdata) {
                console.log(rdata);
                let contents = "";
                let center = rdata.center
                if (center == null || center == undefined || center == "") {
                    contents += "<div class='no-detail'>등록된 데이터가 없습니다.</div>";
                } else {
                    contents += "<div>";
                    contents += "   <div class='card-header'>";
                    contents += "       상세보기";
                    contents += `       <button type='button' onclick='openMymapList("1")' class='btn btn-light'>뒤로</button>`;
                    contents += "   </div>";
                    contents += "   <div class='card-body'> ";
                    contents += "       <div class='multi-box'> ";
                    contents += "           <h2 align='left'>" + center.center_nm + "</h2>";
                    contents += "           <div align='right'>";
                    contents += "               <button class='btn btn-light'>수정</button>"
                    contents += "               <button class='btn btn-light'>삭제</button>"
                    contents += "           </div>";
                    contents += "       </div>";
                    contents += "       <p>" + center.center_desc + "</p>";
                    contents += "   </div>";

                    contents += "   <hr />";
                    contents += "   <div class='detail card-body'>";
                    contents += "       <p class='detail-info'>상세정보</p>";
                    contents += "       <p>주소 : " + center.address + " " + center.detail_address + "</p>";
                    contents += "       <p>브랜드명 : " + center.brand_nm + "</p>";
                    contents += "       <p>지사지점 : " + center.branch_nm + "</p>";
                    contents += "       <p>대상 : " + center.target + "</p>";
                    contents += "       <p>과목 : " + center.subject + "</p>";

                    if (center.option1_nm != null && center.option1_nm != undefined && center.option1_nm != "") {
                        contents += "   <p>" + center.option1_nm + " : " + center.option1_desc + "</p>";
                    }
                    if (center.option2_nm != null && center.option2_nm != undefined && center.option2_nm != "") {
                        contents += "   <p>" + center.option2_nm + " : " + center.option2_desc + "</p>";
                    }
                    if (center.option3_nm != null && center.option3_nm != undefined && center.option3_nm != "") {
                        contents += "   <p>" + center.option3_nm + " : " + center.option3_desc + "</p>";
                    }
                    if (center.option4_nm != null && center.option4_nm != undefined && center.option4_nm != "") {
                        contents += "   <p>" + center.option4_nm + " : " + center.option4_desc + "</p>";
                    }
                    if (center.option5_nm != null && center.option5_nm != undefined && center.option5_nm != "") {
                        contents += "   <p>" + center.option5_nm + " : " + center.option5_desc + "</p>";
                    }
                    if (center.option6_nm != null && center.option6_nm != undefined && center.option6_nm != "") {
                        contents += "   <p>" + center.option6_nm + " : " + center.option6_desc + "</p>";
                    }
                    if (center.option7_nm != null && center.option7_nm != undefined && center.option7_nm != "") {
                        contents += "   <p>" + center.option7_nm + " : " + center.option7_desc + "</p>";
                    }
                    if (center.option8_nm != null && center.option8_nm != undefined && center.option8_nm != "") {
                        contents += "   <p>" + center.option8_nm + " : " + center.option8_desc + "</p>";
                    }
                    if (center.option9_nm != null && center.option9_nm != undefined && center.option9_nm != "") {
                        contents += "   <p>" + center.option9_nm + " : " + center.option9_desc + "</p>";
                    }
                    if (center.option10_nm != null && center.option10_nm != undefined && center.option10_nm != "") {
                        contents += "   <p>" + center.option10_nm + " : " + center.option10_desc + "</p>";
                    }
                    if (center.option11_nm != null && center.option11_nm != undefined && center.option11_nm != "") {
                        contents += "   <p>" + center.option11_nm + " : " + center.option11_desc + "</p>";
                    }
                    if (center.option12_nm != null && center.option12_nm != undefined && center.option12_nm != "") {
                        contents += "   <p>" + center.option12_nm + " : " + center.option12_desc + "</p>";
                    }
                    if (center.option13_nm != null && center.option13_nm != undefined && center.option13_nm != "") {
                        contents += "   <p>" + center.option13_nm + " : " + center.option13_desc + "</p>";
                    }
                    if (center.option14_nm != null && center.option14_nm != undefined && center.option14_nm != "") {
                        contents += "   <p>" + center.option14_nm + " : " + center.option14_desc + "</p>";
                    }
                    if (center.option15_nm != null && center.option15_nm != undefined && center.option15_nm != "") {
                        contents += "   <p>" + center.option15_nm + " : " + center.option15_desc + "</p>";
                    }
                    contents += "   </div>";
                    contents += "</div>";

                    $("#mymapList").append(contents);
                }
            }, error: function (result) {
                console.log(result);
            }
        });
    } else if (type == "property") {

    }

}





/*  ********************** utils **********************  */

function nvl(str, defaultStr) {
    if (typeof str == "undefined" || str == null || str == "")
        str = defaultStr;

    return str;
}
/* 탭 이동 */
$(function () {
    $('ul.tab li').click(function () {
        let activeTab = $(this).attr('data-tab');
        console.log(activeTab);
        $('ul.tab li').removeClass('active');
        $('.tabcont').removeClass('active'); // 모든 탭 내용을 안보이게 처리

        $(this).addClass('active');
        $('#' + activeTab).addClass('active');
    })
});
