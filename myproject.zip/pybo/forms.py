from flask_wtf import FlaskForm
from wtforms import StringField, widgets, SelectField, IntegerField, SelectMultipleField
from wtforms.validators import DataRequired


class MultiCheckboxField(SelectMultipleField):
    widget = widgets.ListWidget(prefix_label=True)
    option_widget = widgets.CheckboxInput()


class AddMarkerForm1(FlaskForm):
    string_of_targets = ['영유아\r\n초등학생\r\n중학생\r\n고등학생\r\n']
    list_of_targets = string_of_targets[0].split()
    targets = [(x, x) for x in list_of_targets]

    string_of_subjects = [
        '국어\r\n영어\r\n수학\r\n사회\r\n과학\r\n제2외국어\r\n논술\r\n예체능\r\n코딩\r\n교구학습\r\n창의력\r\n']
    list_of_subjects = string_of_subjects[0].split()
    subjects = [(x, x) for x in list_of_subjects]

    centerNm = StringField('centerNm',  validators=[DataRequired()])
    centerDesc = StringField('centerDesc', validators=[DataRequired()])
    brandNm = SelectField('brandNm', choices=[('미래탐구', '미래탐구'), ('소마', '소마'), (
        '뉴스터디', '뉴스터디'), ('하이스트', '하이스트'), ('플레이팩토', '플레이팩토'), ('르네상스', '르네상스'), ('ELC', 'ELC')])
    branchNm = SelectField('branchNm', choices=[(
        '대치지점', '대치지점'), ('성북지점', '성북지점'), ('동대문지점', '동대문지점'), ('광화문지점', '광화문지점'), ('목동지점', '목동지점')])
    address = StringField('address', validators=[DataRequired()])
    detailAddress = StringField('detailAddress')
    target = MultiCheckboxField('target', choices=targets)
    subject = MultiCheckboxField('subject', choices=subjects)


class AddMarkerForm2():
    property_nm = StringField('propertyNm',  validators=[DataRequired()])
    property_desc = StringField('propertyDesc', validators=[DataRequired()])
    address = StringField('address', validators=[DataRequired()])