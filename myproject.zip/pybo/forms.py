from flask_wtf import FlaskForm
from wtforms import StringField, widgets, SelectField, IntegerField, SelectMultipleField, TextAreaField, BooleanField
from wtforms.validators import DataRequired, length, StopValidation

# 가르치는 대상
string_of_targets = ['영유아\r\n초등학생\r\n중학생\r\n고등학생\r\n']
list_of_targets = string_of_targets[0].split()
targets = [(x, x) for x in list_of_targets]

# 과목
string_of_subjects = [
    '국어\r\n영어\r\n수학\r\n사회\r\n과학\r\n제2외국어\r\n논술\r\n예체능\r\n코딩\r\n교구학습\r\n창의력\r\n']
list_of_subjects = string_of_subjects[0].split()
subjects = [(x, x) for x in list_of_subjects]


class MultiCheckboxField(SelectMultipleField):
    widget = widgets.ListWidget(html_tag='ol', prefix_label=False)
    option_widget = widgets.CheckboxInput()


class AddMarkerForm1(FlaskForm):
    centerNm = StringField('centerNm',  validators=[
                           DataRequired(), length(max=100)])
    centerDesc = TextAreaField('centerDesc', validators=[
        DataRequired(), length(max=100)])
    brandNm = SelectField('brandNm', choices=[('미래탐구', '미래탐구'), ('소마', '소마'), (
        '뉴스터디', '뉴스터디'), ('하이스트', '하이스트'), ('플레이팩토', '플레이팩토'), ('르네상스', '르네상스'), ('ELC', 'ELC')])
    branchNm = SelectField('branchNm', choices=[(
        '대치지점', '대치지점'), ('성북지점', '성북지점'), ('동대문지점', '동대문지점'), ('광화문지점', '광화문지점'), ('목동지점', '목동지점')])
    address = StringField('address', validators=[DataRequired()])
    detailAddress = StringField('detailAddress')
    # target = MultiCheckboxField('target', choices=targets)
    # subject = MultiCheckboxField('subject', choices=subjects)


class AddMarkerForm2(FlaskForm):
    propertyNm = StringField('propertyNm',  validators=[
                             DataRequired(), length(max=100)])
    propertyDesc = TextAreaField('propertyDesc', validators=[
                                 DataRequired(), length(max=100)])
    address = StringField('address', validators=[DataRequired()])
    detailAddress = StringField('detailAddress')
    areaFeet = IntegerField('areaFeet', validators=[
                            DataRequired(), length(max=99999)])
    floor = IntegerField('floor', validators=[DataRequired(), length(max=999)])
    undrgrndYn = BooleanField('undrgrndYn')
    price = IntegerField('price', validators=[
                         DataRequired(), length(max=999999999999)])
